import jsonpickle
import time
import urllib2
import ast
import requests
import csv
import MySQLdb
import json
import random
import glob
import re

from pyvirtualdisplay import Display
from lxml import html
from selenium import webdriver
from django.http import HttpResponse
from linkedin import linkedin
from datetime import datetime
from lxml import etree
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect
from linkedin_app import pyteaser
from example import settings
from linkedin_app.models import *
from IPython.core.display import display

database = MySQLdb.connect (host=settings.DATABASES['default']['HOST'], 
                            user = settings.DATABASES['default']['USER'], 
                            passwd = settings.DATABASES['default']['PASSWORD'], 
                            db = settings.DATABASES['default']['NAME'])
cursor = database.cursor()

def get_parsed_source(base_url, target_url, raw=False):
    req = urllib2.Request(target_url,
                          headers={'User-Agent': 'Mozilla/5.0' })
    html_opener = urllib2.urlopen(req)
    html_code = html_opener.read()
    if raw:
        return html_code

    parsed_source = html.fromstring(html_code, base_url)
    parsed_source.make_links_absolute()
    return parsed_source


def getText(src, xpath, index=0):
    
    '''this function get the xpath and return the text'''
    tmp = src.xpath(xpath)
    if tmp and len(tmp) > index:
        return tmp[index].strip()
    else:
        return ""

def get_data(request):
    pass
    print "inside get_Data"
    CONSUMER_KEY = '75m1a3um2ynn80'
    CONSUMER_SECRET = '3u6M21ByVyU2tREp'
    USER_TOKEN = '3916ee36-7936-4d8b-8353-242d20212663'
    USER_SECRET='6725f6b9-4307-490a-be8f-0f4b87519d63'

     
    person_obj = person_new.objects.all()
    for data_obj in person_obj:
        person_linkdin_obj= person_linkedin_data()
        person_linkdin_position_obj =person_linkedin_position_new()
        fn = data_obj.fname
        ln = data_obj.lname
        authentication = linkedin.LinkedInDeveloperAuthentication(CONSUMER_KEY, CONSUMER_SECRET, 
                                                                  USER_TOKEN, USER_SECRET, 
                                                              'localhost', linkedin.PERMISSIONS.enums.values())
      

        application = linkedin.LinkedInApplication(authentication)
        data = application.search_profile(selectors=[{'people': ['first-name','last-name','headline','location:(name)'\
                                                            ,'industry','num-connections','specialties','positions','picture-url',\
                                                            'public-profile-url','summary']}], params={'first-name':fn,'last-name':ln,\
                                                            'count':25,'start':0,'scope':'r_fullprofile'})
        try:
             
            data = data['people']['values'][0]
        except Exception as e:
            print fn
            continue
        
        try:
            if data['firstName']:
                person_linkdin_obj.fname = data['firstName']
            else:
                person_linkdin_obj.fname = 'NULL'
        except Exception as e:
            person_linkdin_obj.fname = 'NULL'
            
        try:
            if data['lastName']:
                person_linkdin_obj.lname = data['lastName']
            else:
                person_linkdin_obj.lname = 'NULL'
        except Exception as e:
            person_linkdin_obj.lname='NULL'
            
        person_linkdin_obj.email = 'NULL'
        
        try:
            if data['pictureUrl']:
                person_linkdin_obj.pic_url = data['pictureUrl']
            else:
                person_linkdin_obj.pic_url = 'NULL'
        except Exception as e:
            person_linkdin_obj.pic_url = 'NULL'
            
        try:
            if data['publicProfileUrl']:
                person_linkdin_obj.public_profile_url = data['publicProfileUrl']
            else:
                person_linkdin_obj.public_profile_url = 'NULL'
        except Exception as e:
            person_linkdin_obj.public_profile_url= 'NULL'
            
        try:
            if data['location']['name']:
                person_linkdin_obj.location = data['location']['name']
            else:
                person_linkdin_obj.location = 'NULL'
        except Exception as e:
            person_linkdin_obj.location  ='NULL'
            
        try:
            if data['industry']:
                person_linkdin_obj.industry = data['industry']
            else:
                person_linkdin_obj.industry = 'NULL'
        except Exception as e:
            person_linkdin_obj.industry = 'NULL'
            
        try:
            if data['headline']:
                person_linkdin_obj.headline = data['headline']
            else:
                person_linkdin_obj.headline = 'NULL'
        except Exception as e:
            person_linkdin_obj.headline = ''
        try:
            if data['summary']:
                person_linkdin_obj.summary = data['summary']
            else:
                person_linkdin_obj.summary = 'NULL'
        except Exception as e:
            person_linkdin_obj.summary = 'NULL'
             
        person_linkdin_obj.person_id = data_obj
        person_linkdin_obj.last_updated = datetime.datetime.now()
        try:
            person_linkdin_obj.save()
            time.sleep(20)
        except Exception as e:
            print e
         
 
        person_linkdin_position_obj.person_linkedin_data_id= person_linkdin_obj
        try:
            values = data['positions']['values']
            for val in values:
                try:
                    if val['startDate']['year']:
                        person_linkdin_position_obj.startdate_year =val['startDate']['year']
                    else:
                        person_linkdin_position_obj.startdate_year  = 0
                except Exception as e:
                    person_linkdin_position_obj.startdate_year = 0
                    
                try:
                    if val['startDate']['month']:
                        person_linkdin_position_obj.startdate_month= val['startDate']['month']
                    else:
                        person_linkdin_position_obj.startdate_month = 0
                except Exception as e:
                    person_linkdin_position_obj.startdate_month= 0
                    
                try:
                    if val['endDate']['year']:
                        person_linkdin_position_obj.enddate_year = val['endDate']['year']
                    else:
                        person_linkdin_position_obj.enddate_year = 0
                except Exception as e:
                    person_linkdin_position_obj.enddate_year  =0
                    
                try:
                    if val['endDate']['month']:
                        person_linkdin_position_obj.enddate_month= val['endDate']['month']
                    else:
                        person_linkdin_position_obj.enddate_month = 0
                except Exception as e:
                        person_linkdin_position_obj.enddate_month= 0
                        
                try:
                    if val['isCurrent']:
                        person_linkdin_position_obj.current = val['isCurrent']
                    else:
                        person_linkdin_position_obj.current  = False
                except Exception as e:
                    person_linkdin_position_obj.current  = False
                    
                try:
                    if val['company']['name']:
                        person_linkdin_position_obj.company_name = val['company']['name']
                    else:
                        person_linkdin_position_obj.company_name = 'NULL' 
                except Exception as e:
                    person_linkdin_position_obj.company_name = ''
                    
                try:
                    if val['title']:
                        person_linkdin_position_obj.title = val['title']
                    else:
                        person_linkdin_position_obj.title = 'NULL'
                except Exception as e:
                    person_linkdin_position_obj.title = ''
                     
                try:
                    if val['summary']:
                        person_linkdin_position_obj.summary = val['summary']
                    else:
                        person_linkdin_position_obj.summary = 'NULL'
                except Exception as e:
                    person_linkdin_position_obj.summary = ''
                    
                try:
                    person_linkdin_position_obj.save()
                    time.sleep(20)
                except Exception as e:
                    print e
        except Exception as e:
            print e
            continue
 
    context_dict = {'current': data
                        }
    json_encoded = jsonpickle.encode(context_dict)
    return HttpResponse(json_encoded, mimetype='application/json')
    
def linkedin_get_google_url(name, company_name):
    
    '''this function get the name and designation call the google_api function
    and return the profile_url'''
    
    from xgoogle.search import GoogleSearch, SearchError        #import the GoogleSearch from the xgoogle
    try:
        profile_url=''
        name = name.lower()
        
        company_name = " ".join(company_name.split(' '))
        gs = GoogleSearch(name+" "+company_name+"linkedin")
        gs.results_per_page = 5
        results = gs.get_results()
        for res in results:
            dic_data = res.__dict__
            profile_url =  res.url.encode("utf8")
            company_name_xpath =get_parsed_source("http://in.linkedin.com/",profile_url)
#             import ipdb;ipdb.set_trace()
            current_company = "".join(company_name_xpath.xpath("//tr[@id='overview-summary-current']//td//text()"))
            if name in dic_data['url']:
                if  company_name in current_company:
                    if "LinkedIn" in dic_data['title']:
                        return profile_url
                else:
                    if company_name in dic_data['desc']:
                        if "LinkedIn" in dic_data['title']:
                            return profile_url
                    else:
                        company_name = " ".join(company_name.split(' ')[0:2])
                        if company_name in dic_data['desc']:
                            if "LinkedIn" in dic_data['title']:
                                return profile_url
                        else:
                            company_name = " ".join(company_name.split(' ')[0:1])
                            if company_name in dic_data['desc']:
                                if "LinkedIn" in dic_data['title']:
                                    return profile_url
                            else:
                                continue
            else:
                name = name.split(' ')[0].lower()
                if name in dic_data['url']:
                    if  company_name in current_company:
                        if "LinkedIn" in dic_data['title']:
                            return profile_url
                    else:
                        if company_name in dic_data['desc']:
                            if "LinkedIn" in dic_data['title']:
                                return profile_url
                        else:
                            company_name = " ".join(company_name.split(' ')[0:2])
                            if company_name in dic_data['desc']:
                                if "LinkedIn" in dic_data['title']:
                                    return profile_url
                            else:
                                company_name = " ".join(company_name.split(' ')[0:1])
                                if company_name in dic_data['desc']:
                                    if "LinkedIn" in dic_data['title']:
                                        return profile_url
                                else:
                                    continue
    except SearchError, e:
        print "Search failed: %s" % e
    